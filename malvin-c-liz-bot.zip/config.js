module.exports = {
    botName: "Malvin C Liz",
    ownerName: "Handsome Tech",
    location: "Zimbabwe",
    prefix: ".",
    pairingCode: true // Set to true to use pairing code instead of QR
};
